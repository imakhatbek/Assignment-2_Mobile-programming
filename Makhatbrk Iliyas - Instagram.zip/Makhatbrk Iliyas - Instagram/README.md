# Instagram Clone App

- Firebase Auth used for login and sign up.<br>
- Firebase database is used for data operations.<br>
- Social media app features: post, comment, like, follow and profiles<br>
- This repository is purely kotlin based.<br>
- Activities, fragments and XML layouts.<br>
- Network state check, dialog messages and much more.<br>
- Based on MVP architecture.